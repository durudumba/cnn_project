# CNN-NUMPY-PROJECT
학부 수업용으로 구현된 작은 사이즈의 뉴럴네트워크. 

- 구현 및 수정, 번역: 허종욱
- 뉴럴넷 구조 설계: [@eyyub_s](https://twitter.com/eyyub_s)
- 관련 자료: http://cs231n.stanford.edu/assignments.html

## Requirements
- Python 3.7
- Numpy
